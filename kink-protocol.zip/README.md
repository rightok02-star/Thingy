# Fetish Conditioning Protocol

A local, browser-based daily fetish injection system.

## Features
- Large pool of fetishes from tame → extreme (all legal and commonly available in porn/hentai)
- Randomized daily assignment
- Materials checklist that adapts the session
- Detailed 30–60 minute step-by-step protocols
- Goal of each session: create neurological pull / early addiction to that fetish
- Postpone or permanently remove options with scaling punishments
- Progress tracking, streak, and conditioning log
- Fully client-side (localStorage)

## How to use on mobile + GitHub Pages

1. Create a new **public** repository.
2. Upload these four files:
   - `index.html`
   - `style.css`
   - `script.js`
   - `README.md`
3. Go to **Settings → Pages**
4. Source: branch `main`, folder `/ (root)`
5. Save and wait for the live link.

## Aesthetic
Deep black + electric purple/magenta. Clinical addiction-lab feel. Different from the previous dominatrix site.
